export enum ImageType {
  PROFILE = 'profile',
  STATIC = 'static',
}
