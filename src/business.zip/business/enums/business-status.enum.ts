// src/businesses/enums/business-status.enum.ts
export enum BusinessStatus {
  ACTIVE = 'ACTIVE',
  PENDING = 'PENDING',
  INACTIVE = 'INACTIVE',
}
